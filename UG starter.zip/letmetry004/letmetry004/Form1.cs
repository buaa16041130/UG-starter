﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace letmetry004
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            label2.Text = e.X + "," + e.Y;
        }

        private void button2_Click(object sender, EventArgs e)
        {//Flexlm Service 1
         //Process p = Process.Start("G:/UGS75/UGII/ugraf.exe");
            ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo("G:/UGS75/UGII/ugraf.exe");
            if (service.Status != System.ServiceProcess.ServiceControllerStatus.Running &&
                service.Status != System.ServiceProcess.ServiceControllerStatus.StartPending)
                MessageBox.Show("服务未启动，请先启动服务");
            else
                Process.Start(info);
        }

        System.ServiceProcess.ServiceController service = new System.ServiceProcess.ServiceController("Flexlm Service 1");
        private void button1_Click(object sender, EventArgs e)
        {//启动服务
            if (service.Status == System.ServiceProcess.ServiceControllerStatus.Running)
                MessageBox.Show("服务已启动");
            if (service.Status != System.ServiceProcess.ServiceControllerStatus.Running &&
                service.Status != System.ServiceProcess.ServiceControllerStatus.StartPending)
            {
                service.Start();
                for (int i = 0; i < 60; i++)
                {
                    service.Refresh();
                    System.Threading.Thread.Sleep(1000);
                    if (service.Status == System.ServiceProcess.ServiceControllerStatus.Running)
                    {
                        MessageBox.Show("服务已启动");
                        break;
                    }
                    if (i == 59)
                    {
                        MessageBox.Show("服务启动失败");
                    }
                }
                /*停止服务
                if (service.Status == System.ServiceProcess.ServiceControllerStatus.Running)
                    service.Stop();*/
            }
        }
    }
}
